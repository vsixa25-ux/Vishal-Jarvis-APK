package com.myraa.mobile;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;

/** Keeps an explicitly started Gemini Live session available without drawing over other apps. */
public final class LiveVoiceService extends Service {
  public static final String STOP = "com.myraa.mobile.STOP_LIVE";
  public static volatile boolean running;

  @Override public IBinder onBind(Intent intent) { return null; }

  @Override public int onStartCommand(Intent intent, int flags, int id) {
    if (intent != null && STOP.equals(intent.getAction())) { end(); return START_NOT_STICKY; }

    NotificationManager manager = getSystemService(NotificationManager.class);
    NotificationChannel channel = new NotificationChannel("live_voice", "Vishal Jarvis background voice", NotificationManager.IMPORTANCE_LOW);
    channel.setDescription("Silent notification required while the microphone is active.");
    channel.setShowBadge(false);
    manager.createNotificationChannel(channel);

    PendingIntent stop = PendingIntent.getService(this, 1,
      new Intent(this, LiveVoiceService.class).setAction(STOP),
      PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

    Notification notification = new Notification.Builder(this, "live_voice")
      .setSmallIcon(android.R.drawable.ic_btn_speak_now)
      .setContentTitle("Vishal Jarvis is active")
      .setContentText("Background voice session is running")
      .setOngoing(true)
      .setOnlyAlertOnce(true)
      .setSilent(true)
      .setCategory(Notification.CATEGORY_SERVICE)
      .addAction(new Notification.Action.Builder(null, "Stop", stop).build())
      .build();

    if (Build.VERSION.SDK_INT >= 30) {
      startForeground(42, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
    } else {
      startForeground(42, notification);
    }
    running = true;
    return START_NOT_STICKY;
  }

  private void end() {
    running = false;
    sendBroadcast(new Intent(STOP).setPackage(getPackageName()));
    stopForeground(true);
    stopSelf();
  }

  @Override public void onTaskRemoved(Intent root) { end(); }
  @Override public void onDestroy() { running = false; super.onDestroy(); }
}
