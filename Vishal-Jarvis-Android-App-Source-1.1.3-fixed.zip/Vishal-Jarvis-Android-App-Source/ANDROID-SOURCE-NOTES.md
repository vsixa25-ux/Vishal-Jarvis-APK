# Android source notes — Vishal Jarvis

The Android app keeps its original native package ID and bridge/prefs/event names for
compatibility, while its visible app name and assistant identity are Vishal Jarvis.
The mobile 3D character is now `src/mobile/RobotCharacter.ts`, a self-contained
procedural Three.js male android. It replaces the previously referenced external
Evelyn PMX model which was not included in this separated source ZIP.

The Android build no longer copies or requires third-party PMX model files. Its
mobile UI still uses the existing Gemini/Android chat, voice, settings, action and
history implementation. This source package has not yet been rebuilt or retested on
a physical Android device after the rename and character replacement.
